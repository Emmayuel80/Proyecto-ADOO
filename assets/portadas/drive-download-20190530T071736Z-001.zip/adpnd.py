# a^n b^2n

Q=['q1','q2']
F=['q1']
R=['A','B','Z']
S='q1'
z='A'

DELTA={('q1','a','A'):['q2','BBA'],
       ('q1','','A'):['q4','A'],
       ('q2','a','B'):['q2','BBB'],
       ('q2','b','B'):['q3',''],
       ('q3','b','B'):['q3',''],
       ('q3','','A'):['q4','A'],
       }



def transicion(estado,sigma,top):
       print(estado+sigma+top)
       try:
              aux=DELTA[estado,sigma,top]
              estado_siguiente=aux[0]
              pila.pop()
              for x in range(0,len(top)):
                     pila.append(top[x])
       except KeyError:
             estado_siguiente='0' 
       print(estado_siguiente+" pila"+len(pila))

       return estado_siguiente

ejemplos=['a','b','aab','aabb','aaaabbb','abb']

for w in ejemplos:
       pila=[z]
       estado=S
       for i in range(0,len(w)):
              estado=transicion(estado,w[i],pila[len(pila)-1])
              if estado =='0':
                     break
       if not (estado in F) and (estado!='0'):
              while  (estado!='0' or estado in F):
                     estado=transicion(estado,'',pila[len(pila)-1])

       if estado in F:
              print(w,"si esta en el lenguje ",estado)
       else:
                  print(w,"no esta en el lenguje ",estado)